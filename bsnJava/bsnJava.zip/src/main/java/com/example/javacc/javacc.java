package com.example.javacc;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hyperledger.fabric.shim.ChaincodeBase;
import org.hyperledger.fabric.shim.ChaincodeStub;

import java.util.List;

public class javacc extends ChaincodeBase {
    private static Log _logger = LogFactory.getLog(javacc.class);

    @Override
    public Response init(ChaincodeStub chaincodeStub) {
        String func=chaincodeStub.getFunction();
        if (func.equals("init")){
            return newErrorResponse("func name must be init");

        }
        chaincodeStub.putStringState("init","this is init");
        return newSuccessResponse("init success");
    }

    @Override
    public Response invoke(ChaincodeStub chaincodeStub) {
        String func=chaincodeStub.getFunction();
        List<String> params=chaincodeStub.getParameters();


        return newSuccessResponse("hello");
    }
}
